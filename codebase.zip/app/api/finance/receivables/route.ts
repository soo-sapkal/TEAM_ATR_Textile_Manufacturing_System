import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { Pool } from "pg";
import { verifyToken } from "@/lib/auth/auth";
import { snakeToCamel } from "@/lib/supabase/adapter";

export const dynamic = "force-dynamic";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || "postgresql://postgres.xaqbisnaetgsjiortzgi:sohamsapkal@aws-0-ap-northeast-1.pooler.supabase.com:5432/postgres",
});

export async function GET() {
  const cookieStore = await cookies();
  const token = cookieStore.get("auth_token")?.value;
  if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  
  const payload = await verifyToken(token) as any;
  let permissions = payload?.permissions || [];
  if (permissions.length === 0 && payload?.role) {
    const { ROLE_PERMISSIONS } = await import("@/lib/auth/permissions");
    permissions = ROLE_PERMISSIONS[payload.role]?.perms || [];
  }

  if (!payload || !permissions.includes("finance.read")) {
    return NextResponse.json({ success: false, error: "Forbidden: Requires finance.read permission" }, { status: 403 });
  }

  try {
    // The invoices and payments tables do not exist in the current schema.
    // Returning empty arrays to avoid Postgres 'relation does not exist' errors.
    return NextResponse.json({
      success: true,
      data: {
        invoices: [],
        payments: [],
      }
    });
  } catch (error) {
    console.error("Finance GET error:", error);
    return NextResponse.json({ success: false, error: "Failed to fetch finance data" }, { status: 500 });
  }
}
